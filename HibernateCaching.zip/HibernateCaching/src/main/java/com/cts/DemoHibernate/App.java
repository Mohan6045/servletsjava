package com.cts.DemoHibernate;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 * Hello world
 *
 */
public class App 
{
    public static void main( String[] args )
     
    {
        System.out.println( "Hello World!" );
        
       
        
        Alien telusko =  new Alien();
        
       
        
        Configuration config =  new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Alien.class);
        
        ServiceRegistry reg =new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
         
        SessionFactory SF=config.buildSessionFactory(reg);  //  this is old before 4.1
        
        Session session1 =SF.openSession();
        
        session1.beginTransaction();
        
        
        Query q1= session1.createQuery("from Alien where aid=6");
        q1.setCacheable(true);
        
        telusko =(Alien)q1.uniqueResult();
        
        
        
        
        
        
       // telusko=(Alien)session1.get(Alien.class, 10);
        System.out.println(telusko);
        session1.getTransaction().commit();
        session1.close();
         
       
    
        Session session2 =SF.openSession();
        
        session2.beginTransaction();
        
        Query q2= session2.createQuery("from Alien where aid=6");
        q2.setCacheable(true);
        
        telusko =(Alien)q2.uniqueResult();
        
        
        
       // telusko=(Alien)session2.get(Alien.class, 10);
        System.out.println(telusko);
        session2.getTransaction().commit(); 
        session2.close();
    }
}
