package com.cts.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.web.Dao.AlienDao;

/**
 * Servlet implementation class GetAleinController
 */
@WebServlet("/getAlien")
public class GetAleinController extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	int number=Integer.parseInt(request.getParameter("aid"));
	
	AlienDao dao= new AlienDao();		
	System.out.println(dao);
	
	
	
	Alien A1= dao.getAlien(number);
	
		System.out.println(A1);	
		
		
   request.setAttribute("alien",A1);		
	

	
	RequestDispatcher r1=request.getRequestDispatcher("ShowAlien.jsp");  // use this methods when passing object
	r1.forward(request, response);
	
//response.sendRedirect("ShowAlien.jsp");  to use this use sessionn to store the value
	
		
	}

	}

