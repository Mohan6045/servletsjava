package com.cts.DemoHibernate;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import net.sf.ehcache.search.expression.Criteria;

/**
 * Hello world
 *
 */
public class App12 
{
    public static void main( String[] args )
     
    {
        System.out.println( "Hello World!" );
        
        Configuration config =  new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Student.class);
        
        ServiceRegistry reg =new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
         
        SessionFactory SF=config.buildSessionFactory(reg);  
        
        Session sess =SF.openSession();
        Random r= new Random();
        
        sess.beginTransaction();
        
        
//        for(int i=1;i<=50;i++)
//        {
//        	Student s1 =new Student();
//        	s1.setRollno(i);                                    //    saving 50 data in database
//        	s1.setName("Name"+i);
//        	s1.setMarks(r.nextInt(100));;
//        	sess.save(s1);	
//        }
        
            
//        Query q=sess.createQuery("from Student where rollno=7");
//        List<Student> Studentsdet=q.list();
//        for(Student s: Studentsdet)
//        {
//        	System.out.println(s);
//        }
        
        
//        Query q=sess.createQuery("Select rollno,name,marks from Student where rollno=7");
//        Object[] student= (Object[])q.uniqueResult();
//        for(Object O:student)
//        {
//        	System.out.println(O);
//        }
        
        
        
//        Query q=sess.createQuery("Select rollno,name,marks from Student s where  s.marks >60");    // 			 alias
//        List<Object[]> l = q.list();
//        for(Object[] s:l)
//	       {
//	    	   System.out.println(s[0]+" :"+s[1]+" :"+s[2]);
//	       }
        
        
        //     ||
        //     || 
        //     \/     SQL
        
        
        
        // native Queries.....> using sql in hibernate
//        SQLQuery query = sess.createSQLQuery("Select * from Student where marks>60");
//        
//        query.addEntity(Student.class);
//        
//        List<Student> students =query.list();
//        
//        for(Object O: students)
//        {
//        	System.out.println(O);
//        }
        
        
        
       SQLQuery query = sess.createSQLQuery("Select name,marks from Student where marks>60");
        query.setResultTransformer(org.hibernate.Criteria.ALIAS_TO_ENTITY_MAP);
        List<Student> students =query.list();
        
        for(Object O: students)
        {
        	
        	Map m=(Map)O;
        	System.out.println(m.get("name")+"  ... "+m.get("marks"));
        }
        
        
        
      
        sess.getTransaction().commit(); 
        
    }
}
