package com.cts.Hibernate_Mapping_Relations;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        
        
        Laptop laptop =new Laptop();
        laptop.setLid(101);
        laptop.setLname("Dell");
        
               
        
        
        Student s= new Student();
        s.setName("mohan");
        s.setMarks(50);
        s.setRollno(1);
       //   s.setLaptop(laptop);   1-1
        
    //   s.getLaptop().add(laptop) ;
        
        
        laptop.getStudent().add(s);
       
        
        Configuration con =new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Laptop.class).addAnnotatedClass(Student.class);
        
        
        ServiceRegistry registry = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
        
        SessionFactory SF= con.buildSessionFactory(registry);
        
        Session session = SF.openSession();
        
        session.beginTransaction();
        
        
        session.save(laptop);
        session.save(s);
        
        
        session.getTransaction().commit();
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
