package com.Login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/Logout")     //  connecting the Logout.jsp page through action value in form page



public class Logout extends HttpServlet {     

	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		HttpSession session =request.getSession();    // declaring the session 
		session.removeAttribute("username");          //  removing the username attribute 
		session.invalidate();                         // deletes all valid credentials
		response.sendRedirect("Login.jsp");           // again comes to login page
		
	}


}
