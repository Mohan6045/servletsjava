package com.cts.demo;

import org.springframework.stereotype.Component;

@Component
public class Laptop {

	public void compile() {
		
		
		System.out.println("complied Code");
	}

}
