package com.cts.DemoHibernate;

import javax.persistence.Embeddable;

@Embeddable
public class AlienName {

	private String fname;
	private String Lname;
	private String mname;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	@Override
	public String toString() {
		return "AlienName [fname=" + fname + ", Lname=" + Lname + ", mname=" + mname + "]";
	}
	
	
	
}
