package com.Login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

import com.Login.Dao.LoginDao;


@WebServlet("/Login")           //  connecting the Login.jsp page through action value in form page

public class Login extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String Name=request.getParameter("name");      //  Getting the name entered in the form
		String Password=request.getParameter("pass");  //  Getting the password entered in the form 
		
		
		LoginDao LD= new LoginDao();
		
		String pass = null;
		try {
			if(LD.Check(Name, Password))   //  validating the form 	  using jdbc i.e.,		
			{	
				
				HttpSession session =request.getSession();   // declaring the session 
				session.setAttribute("username", Name);		// using username as label validating	
				response.sendRedirect("Welcome.jsp");       //  navigates to welcome page if entered username and password is correct
			}
			
			
//		if(Name.equals("mohan") && Password.equals("kumar"))   //  validating the form 			
//		{
//			
//			HttpSession session =request.getSession();   // declaring the session 
//			session.setAttribute("username", Name);		// using username as label validating	
//			response.sendRedirect("Welcome.jsp");       //  navigates to welcome page if entered username and password is correct
//		}
			

			
			else
				
			{
			System.out.println("incorrect");
				response.sendRedirect("Login.jsp");       // comes to same page if the credentials is incorrect i.e, username is incorrect and left blank
				
			}
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	

}
