package serveltdemo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class serconfigaAndcontext extends HttpServlet{
	
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		PrintWriter out =res.getWriter();
		
		out.print("hi");
		
		
		ServletContext SC=req.getServletContext();
		String s=SC.getInitParameter("name");
		out.write(s);
		
		
	}
}
