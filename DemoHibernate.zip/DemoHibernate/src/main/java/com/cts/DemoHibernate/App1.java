package com.cts.DemoHibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 * Hello world!
 *
 */
public class App1                 // different 
{
    public static void main( String[] args )
     
    {
        System.out.println( "Hello World!" );
        
        
        AlienName AN= new AlienName();
        AN.setFname("mohan");
        AN.setLname("kumar");
        AN.setMname("s");
        
        Alien telusko =  new Alien();
        
        telusko.setAid(6);                           //    1.  setting into database
        telusko.setAname(AN);
        telusko.setColor("blue"); 
        
        Configuration config =  new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Alien.class);
        
        ServiceRegistry reg =new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
         
        SessionFactory SF=config.buildSessionFactory(reg);  //  this is old before 4.1
        
        Session session =SF.openSession();
         
        Transaction tx  = session.beginTransaction();
        
          session.save(telusko);                       //        1. saving the object so as to persist to database
          
     //   telusko = (Alien) session.get(Alien.class, 6);          // 2. fetching the data form database and storing them in object
       
        tx.commit();
        
        System.out.println(telusko);
             
    }
}
