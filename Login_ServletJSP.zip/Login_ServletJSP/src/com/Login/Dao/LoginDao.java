package com.Login.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.TimeZone;

public class LoginDao {
	
	
	String url="jdbc:mysql://localhost/mohan1?serverTimezone=" + TimeZone.getDefault().getID();	
	String sql="SELECT * FROM details  where name1=? and pass2=?";
	
	public boolean Check(String name1,String pass2) throws SQLException
	
	{
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con=DriverManager.getConnection(url,"root","");
			
			PreparedStatement st=con.prepareStatement(sql);
			
			st.setString(1, name1);
			st.setString(2, pass2);
			
			ResultSet rs=st.executeQuery();
			
			if(rs.next())
			{
				
				System.out.println("truefd");
				return true;
				
			}
			
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
		return false;
		
	}
}
