package com.cts.DemoHibernate;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import net.sf.ehcache.search.expression.Criteria;

/**
 * Hello world
 *
 */
public class App12 
{
    public static void main( String[] args )
     
    {
        System.out.println( "Hello World!" );
        
        Configuration config =  new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Laptop.class);
        
        ServiceRegistry reg =new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
         
        SessionFactory SF=config.buildSessionFactory(reg);  
        
        Session sess =SF.openSession();
        
        Random r = new Random();
       
        
        sess.beginTransaction();
        
        
//        for(int i=1;i<=50;i++)
//        {
//        	Laptop l =new Laptop();
//        	l.setLid(i);
//        	l.setLname("Brand"+i);
//        	l.setPrice(r.nextInt(1000));
//        	sess.save(l);	
//        }
        
        
        Laptop l =new Laptop();     // transisent state
    	l.setLid(52);
    	l.setLname("Lenevo");
    	l.setPrice(700);
    	sess.save(l);     //  persistence state
    	l.setPrice(650);            //   takes this value only..
    	
 
        sess.getTransaction().commit();
        
        
    }
}
