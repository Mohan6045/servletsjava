package serveltdemo;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/JST")
public class JST  extends HttpServlet {
	public void service(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException
	{
	
		
		String name="mohan";
	
		request.setAttribute("label", name);
		
		RequestDispatcher RD=request.getRequestDispatcher("JStl.jsp");    //   from one servlet to anther servlet       res.sendRedirect
		RD.forward(request, response);
		
		
	}
}
