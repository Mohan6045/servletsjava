package serveltdemo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



//   @WebServlet("/add")
public class AddServlet extends HttpServlet{
	
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		
		int i= Integer.parseInt(req.getParameter("num"));
		int j = Integer.parseInt(req.getParameter("num1"));
		
		
		int  k1= i+j;
		
		String k=String.valueOf(k1);
		
//		PrintWriter out =res.getWriter();
//		
//		out.write("result is  "+k);
		
//		req.setAttribute("k", k);
//		RequestDispatcher RD=req.getRequestDispatcher("sq");    //   from one servlet to anther servlet       res.sendRedirect
//		RD.forward(req, res);
		
		
//		HttpSession session = req.getSession();   // passing  the parameters  through session
//				session.setAttribute("k",k);
				
		Cookie cookie=new Cookie("k", k);    //  passing the parameters through cookie
		res.addCookie(cookie);
				
				
		
		
		res.sendRedirect("sq");
		
	}

}
