package com.cts.Java_Persistence_Api_JPADemo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Alien {
	

	@Id
	private int  ID;
	private String Name;
	private String tech;
	
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getTech() {
		return tech;
	}
	public void setTech(String tech) {
		this.tech = tech;
	}
	@Override
	public String toString() {
		return "Alien [ID=" + ID + ", Name=" + Name + ", tech=" + tech + "]";
	}
	
	
	
	
	
	
	
	
	

}
