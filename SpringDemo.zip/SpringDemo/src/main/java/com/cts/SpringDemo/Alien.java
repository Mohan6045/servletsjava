package com.cts.SpringDemo;

public class Alien {
	
	
	public void code() {
		System.out.println();
	}

}
