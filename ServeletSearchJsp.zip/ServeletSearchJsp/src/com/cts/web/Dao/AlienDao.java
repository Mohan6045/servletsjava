package com.cts.web.Dao;

import com.cts.web.Alien;
import java.sql.*;
import java.util.TimeZone;

public class AlienDao {
	
	
	
	public Alien getAlien( int aid)
	{
		
		String url="jdbc:mysql://localhost/college?serverTimezone=" + TimeZone.getDefault().getID();	
		String sql="SELECT * FROM list where ID="+ aid;
		
		
		Alien a = new Alien();
		
//		a.setAid(aid);
//		a.setAname("mohan");
//
//		a.setTech("java");
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con=DriverManager.getConnection(url,"root","");
			
			Statement st=con.createStatement();
			
	         ResultSet RS=st.executeQuery(sql);
			
	         
	         if(RS.next())
	        	 
	         {
	        	 a.setAid(RS.getInt("ID"));
	        	 a.setAname(RS.getString("Name"));
	        	 a.setTech(RS.getString("tech"));
	        	 
	         }
	        	 
	        	 
			
			
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return a;
	}

}
